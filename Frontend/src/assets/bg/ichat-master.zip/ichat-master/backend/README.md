# backend
	The backend part is a Spring Boot application

## setup

```
- Go to backend folder:
	$ cd backend
- Run the following maven command:
	$ mvn spring-boot:run
The port 8080 is used so please make sure that it is not used by another process
```