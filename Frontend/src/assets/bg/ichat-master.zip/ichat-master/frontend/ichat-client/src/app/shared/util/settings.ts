export const settings = {
        baseUrl: 'http://localhost:8080'
}